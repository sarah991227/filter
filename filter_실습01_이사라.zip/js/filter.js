$(function(){
    const tagged = {};
    //공백 객체
    $("#gallery img").each(function(){
        const img = this;
        const tags = $(this).data('tags');
        //현재 상태의 데이타 테그를 뽑아서 테그즈 에 넣어라

        if(tags){
            tags.split(',').forEach(function(tagName){
            //콤마로 분리해서 배열로 들어가라 
            //data-tags 콤마 앞뒤로 스페이스 가 있으면 안됨
            if(tagged[tagName]==null){
                tagged[tagName] = [];
            }
            tagged[tagName].push(img);
            });
        }
    });
    //all(first) 을 누르면 다 나오게끔 해야된다
    $(".first a").on("click",function(){
        $("#button li").removeClass('active');
        $(this).addClass('active')
        $("#gallery img").show();
        return false;
    });

    $.each(tagged,function(tagName){
        $("#button li").on("click",function(){
            $(".first a").removeClass('active');
            //all 에서 active 를 빼라
            const aa = $(this).text();
            //aa는 누른 버튼이름 저장
            $(this).addClass('active').siblings().removeClass('active');
            //누른버튼에에 액티브클라스 붙여서 색깔 바꾸고 다른 버튼들은 다 리무브 
            $("#gallery img").hide().filter(tagged[aa]).show();
            //tagged리스트에서 버튼이름과 같은거 골라서 보여줌
            
        });//click 종료
    });//.each 종료
});