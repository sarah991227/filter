$(function(){
    const $imgs = $('#gallery img');
    const $search = $('#filter-search');
    const cache = [];

    $imgs.each(function(){
        cache.push({
            element:this,
            text:this.alt.trim().toLowerCase()
            // 현재의 alt값의 양쪽 공백 없에고 모두 소문자로 바꿔서 text에 넣어라
        })
    });

    function filter(){
        const query = this.value.trim().toLowerCase();
        cache.forEach(function(img){
            let index = 0;
            if(query){
                // 데이타가 들어 있으면
                index = img.text.indexOf(query);
            }
            img.element.style.display = index === -1 ? 'none' : '';
            //값을 못 찾았을땐 -1
            //=== 는 '2' 와 2 가 다른걸 감지, 데이타 타입까지 같아야 함
            //display:none 이면 안나오는거 ''이면 나오는거
        });
    }
    $search.on('keyup',filter);
    // keyup할때마다 필터함수 눌러라
    //키보드를 눌렀다 땔데
});